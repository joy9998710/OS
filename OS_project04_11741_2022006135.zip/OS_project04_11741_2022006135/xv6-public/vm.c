#include "param.h"
#include "types.h"
#include "defs.h"
#include "x86.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "elf.h"

extern char data[];  // defined by kernel.ld
pde_t *kpgdir;  // for use in scheduler()

// Set up CPU's kernel segment descriptors.
// Run once on entry on each CPU.
void
seginit(void)
{
  struct cpu *c;

  // Map "logical" addresses to virtual addresses using identity map.
  // Cannot share a CODE descriptor for both kernel and user
  // because it would have to have DPL_USR, but the CPU forbids
  // an interrupt from CPL=0 to DPL=3.
  c = &cpus[cpuid()];
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
  lgdt(c->gdt, sizeof(c->gdt));
}

// Return the address of the PTE in page table pgdir
// that corresponds to virtual address va.  If alloc!=0,
// create any required page table pages.
static pte_t *
//va는  virtual address를 의미하고 alloc은 boolean 변수로 va가 유효하지 않을 때 새로운 va를 할당해 줄 것 인지를 결정
walkpgdir(pde_t *pgdir, const void *va, int alloc)
{
  //page directory entry 즉 page table의 시작 주소를 가리킴
  pde_t *pde;
  //page table의 시작 주소를 가리킴
  pte_t *pgtab;

  /*xv6에서는 Page table이 2 level hierarchy로 이루어짐
    그렇기에 offset이 총 3개 필요
    첫 10bit (PDX)는 page directory에서의 offset을 나타냄
    두번째 10bit(PTX)는 page table에서의 offset을 나타냄
    마지막 12비트는 그 page 안에서의 offset을 나타냄*/
  //PDX를 통해서 page directory의 offset을 활용해서 page table의 위치를 찾음
  pde = &pgdir[PDX(va)];
  //page table이, 즉, page directory entry가 present(유효한지) 확인
  if(*pde & PTE_P){
    //page table이 유효하다면 찾은 page directory entry를 주소로 변환시켜(뒤에 offset 12bit는 0으로 즉 page table의 시작주소)
    //이를 virtual address로 바꿔서 page table의 주소를 얻어냄
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
  } else {
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
      return 0;
    // Make sure all those PTE_P bits are zero.
    memset(pgtab, 0, PGSIZE);
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }
  //page table을 찾았으면 PTX를 통해 page table의 offset을 활용해서 page table에서 memory frame주소를 찾아냄
  //그리고 그 주소를 만환
  return &pgtab[PTX(va)];
}

// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa. va and size might not
// be page-aligned.
static int
mappages(pde_t *pgdir, void *va, uint size, uint pa, int perm)
{
  char *a, *last;
  pte_t *pte;

  a = (char*)PGROUNDDOWN((uint)va);
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
  for(;;){
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
      return -1;
    if(*pte & PTE_P)
      panic("remap");
    *pte = pa | perm | PTE_P;
    if(a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

// There is one page table per process, plus one that's used when
// a CPU is not running any process (kpgdir). The kernel uses the
// current process's page table during system calls and interrupts;
// page protection bits prevent user code from using the kernel's
// mappings.
//
// setupkvm() and exec() set up every page table like this:
//
//   0..KERNBASE: user memory (text+data+stack+heap), mapped to
//                phys memory allocated by the kernel
//   KERNBASE..KERNBASE+EXTMEM: mapped to 0..EXTMEM (for I/O space)
//   KERNBASE+EXTMEM..data: mapped to EXTMEM..V2P(data)
//                for the kernel's instructions and r/o data
//   data..KERNBASE+PHYSTOP: mapped to V2P(data)..PHYSTOP,
//                                  rw data + free physical memory
//   0xfe000000..0: mapped direct (devices such as ioapic)
//
// The kernel allocates physical memory for its heap and for user memory
// between V2P(end) and the end of physical memory (PHYSTOP)
// (directly addressable from end..P2V(PHYSTOP)).

// This table defines the kernel's mappings, which are present in
// every process's page table.
static struct kmap {
  void *virt;
  uint phys_start;
  uint phys_end;
  int perm;
} kmap[] = {
 { (void*)KERNBASE, 0,             EXTMEM,    PTE_W}, // I/O space
 { (void*)KERNLINK, V2P(KERNLINK), V2P(data), 0},     // kern text+rodata
 { (void*)data,     V2P(data),     PHYSTOP,   PTE_W}, // kern data+memory
 { (void*)DEVSPACE, DEVSPACE,      0,         PTE_W}, // more devices
};

// Set up kernel part of a page table.
/* 모든 프로세스는 커널 영역을 공유함
   그렇기에 새로운 프로세스가 생겼을 때 page directory entry를 할당받고(page table) 이를 mapping*/
pde_t*
setupkvm(void)
{
  //page directory entry를 할당받을 것임
  pde_t *pgdir;
  struct kmap *k;

  //kalloc을 통해 page directory entry 하나를 할당받음, 즉 page table 하나를 할당받는 것
  if((pgdir = (pde_t*)kalloc()) == 0)
    return 0;
  //page table의 모든 것을 0으로 초기화
  memset(pgdir, 0, PGSIZE);
  if (P2V(PHYSTOP) > (void*)DEVSPACE)
    panic("PHYSTOP too high");
  //kernel 영역 mapping을 함, 결국 모든 프로세스가 동일한 과정을 거치기에 kernel 영역은 공유하게 됨
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
    if(mappages(pgdir, k->virt, k->phys_end - k->phys_start,
                (uint)k->phys_start, k->perm) < 0) {
      freevm(pgdir);
      return 0;
    }
  return pgdir;
}

// Allocate one page table for the machine for the kernel address
// space for scheduler processes.
void
kvmalloc(void)
{
  kpgdir = setupkvm();
  switchkvm();
}

// Switch h/w page table register to the kernel-only page table,
// for when no process is running.
void
switchkvm(void)
{
  lcr3(V2P(kpgdir));   // switch to the kernel page table
}

// Switch TSS and h/w page table to correspond to process p.
void
switchuvm(struct proc *p)
{
  if(p == 0)
    panic("switchuvm: no process");
  if(p->kstack == 0)
    panic("switchuvm: no kstack");
  if(p->pgdir == 0)
    panic("switchuvm: no pgdir");

  pushcli();
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
                                sizeof(mycpu()->ts)-1, 0);
  mycpu()->gdt[SEG_TSS].s = 0;
  mycpu()->ts.ss0 = SEG_KDATA << 3;
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
  // setting IOPL=0 in eflags *and* iomb beyond the tss segment limit
  // forbids I/O instructions (e.g., inb and outb) from user space
  mycpu()->ts.iomb = (ushort) 0xFFFF;
  ltr(SEG_TSS << 3);
  lcr3(V2P(p->pgdir));  // switch to process's address space
  popcli();
}

// Load the initcode into address 0 of pgdir.
// sz must be less than a page.
void
inituvm(pde_t *pgdir, char *init, uint sz)
{
  char *mem;

  if(sz >= PGSIZE)
    panic("inituvm: more than a page");
  mem = kalloc();
  memset(mem, 0, PGSIZE);
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W|PTE_U);
  memmove(mem, init, sz);
}

// Load a program segment into pgdir.  addr must be page-aligned
// and the pages from addr to addr+sz must already be mapped.
int
loaduvm(pde_t *pgdir, char *addr, struct inode *ip, uint offset, uint sz)
{
  uint i, pa, n;
  pte_t *pte;

  if((uint) addr % PGSIZE != 0)
    panic("loaduvm: addr must be page aligned");
  for(i = 0; i < sz; i += PGSIZE){
    if((pte = walkpgdir(pgdir, addr+i, 0)) == 0)
      panic("loaduvm: address should exist");
    pa = PTE_ADDR(*pte);
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, P2V(pa), offset+i, n) != n)
      return -1;
  }
  return 0;
}

// Allocate page tables and physical memory to grow process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.
/* 
  모든 프로세스는 kernel 영역을 공유함, mapping 되어 있는 것은 오직 커널 영역 뿐
  process가 user virtual memory에 대한 Physical memory를 할당받기 위해서는
  kernel 영역의 free memory 부분에서 할당받는 방법밖에 없음 => 이말인 즉슨 커널 영역과
  user 영역의 virtual address는 다르겠지만 실제로 까보면 (physical address로 변환해보면)
  그 물리주소 값이 서로 같음
*/
int
allocuvm(pde_t *pgdir, uint oldsz, uint newsz)
{
  char *mem;
  uint a;

  if(newsz >= KERNBASE)
    return 0;
  if(newsz < oldsz)
    return oldsz;

  //새로운 페이지 할당을 위해 oldsz를 roundup 해줌
  a = PGROUNDUP(oldsz);
  for(; a < newsz; a += PGSIZE){
    //newsz가 될때까지 kernel 영역에서 메모리 할당이 일어남
    mem = kalloc();
    if(mem == 0){
      panic("allocuvm; out of memory");
    }
    //할당된 user 영역 메모리를 0으로 초기화함
    memset(mem, 0, PGSIZE);
    //새로운 user 영역 memory page를 page table에 mapping시켜줌
    if(mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
      panic("allocuvm; out of memory");
      return 0;
    }
  }
  //새로운 사이즈를 리턴
  return newsz;
}

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
int
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
{
  pte_t *pte;
  uint a, pa;

  if(newsz >= oldsz)
    return oldsz;

  a = PGROUNDUP(newsz);
  for(; a  < oldsz; a += PGSIZE){
    pte = walkpgdir(pgdir, (char*)a, 0);
    if(!pte)
      a = PGADDR(PDX(a) + 1, 0, 0) - PGSIZE;
    else if((*pte & PTE_P) != 0){
      pa = PTE_ADDR(*pte);
      if(pa == 0)
        panic("kfree");
      char *v = P2V(pa);
      kfree(v);
      *pte = 0;
    }
  }
  return newsz;
}

// Free a page table and all the physical memory pages
// in the user part.
void
freevm(pde_t *pgdir)
{
  uint i;

  if(pgdir == 0)
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
  for(i = 0; i < NPDENTRIES; i++){
    if(pgdir[i] & PTE_P){
      char * v = P2V(PTE_ADDR(pgdir[i]));
      kfree(v);
    }
  }
  kfree((char*)pgdir);
}

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void
clearpteu(pde_t *pgdir, char *uva)
{
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
  if(pte == 0)
    panic("clearpteu");
  *pte &= ~PTE_U;
}

// Given a parent process's page table, create a copy
// of it for a child.
// 부모 프로세스의 페이지 테이블을 이용해 copy를 만들어 child에게 줌
pde_t*
copyuvm(pde_t *pgdir, uint sz)
{
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;

  if((d = setupkvm()) == 0)
    return 0;
  for(i = 0; i < sz; i += PGSIZE){
    if((pte = walkpgdir(pgdir, (void *) i, 0)) == 0)
      panic("copyuvm: pte should exist");
    if(!(*pte & PTE_P))
      panic("copyuvm: page not present");
    pa = PTE_ADDR(*pte);
    flags = PTE_FLAGS(*pte);
    //페이지를 복사가 아닌 공유
    //읽기전용으로 만들어버림
    flags &= ~PTE_W;

    if(mappages(d, (void*)i, PGSIZE, pa, flags) < 0) {
      goto bad;
    }
    incr_refc(pa);
  }
  lcr3(V2P(d));
  return d;

bad:
  freevm(d);
  return 0;
}
//PAGEBREAK!
// Map user virtual address to kernel address.
char*
uva2ka(pde_t *pgdir, char *uva)
{
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
  if((*pte & PTE_P) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  return (char*)P2V(PTE_ADDR(*pte));
}

// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int
copyout(pde_t *pgdir, uint va, void *p, uint len)
{
  char *buf, *pa0;
  uint n, va0;

  buf = (char*)p;
  while(len > 0){
    va0 = (uint)PGROUNDDOWN(va);
    pa0 = uva2ka(pgdir, (char*)va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (va - va0);
    if(n > len)
      n = len;
    memmove(pa0 + (va - va0), buf, n);
    len -= n;
    buf += n;
    va = va0 + PGSIZE;
  }
  return 0;
}

int
countvp(void){
  struct proc *p = myproc();
  pde_t *pgdir = p->pgdir;
  int count = 0;
  uint va;
  uint sz = PGROUNDUP(p->sz);
  
  for(va = 0; va < sz; va += PGSIZE){
    pte_t *pte = walkpgdir(pgdir, (void *)va, 0);
    if(pte && (*pte & PTE_P)){
      count++;
    }
  }
  return count;
}

int
sys_countvp(void){
  return countvp();
}

int
countpp(void){
  struct proc *p = myproc();
  int count = 0;
  pde_t *pgdir = p->pgdir;

  // page directory entry 순회
  for(int i = 0; i < PDX(KERNBASE); i++){
    if(pgdir[i] & PTE_P){
      pte_t *pgtab = (pte_t *)P2V(PTE_ADDR(pgdir[i]));
      // page table entry 순회
      for(int j = 0; j < NPTENTRIES; j++){
        if(pgtab[j] & PTE_P){
          count++;
        }
      }
    }
  }
  return count;
}

int
sys_countpp(void){
  return countpp();
}

int
countptp(void)
{
  struct proc *p = myproc();
  pde_t *pgdir = p->pgdir;
  int count = 0;

  // 페이지 디렉토리 자체의 페이지를 포함
  count++; 

  for (int i = 0; i < NPDENTRIES; i++) {
    if (pgdir[i] & PTE_P) {
      // 페이지 디렉토리 엔트리가 존재하면 페이지 디렉토리 엔트리 카운트
      count++;
    }
  }

  return count;
}



int
sys_countptp(void){
  return countptp();
}

void
CoW_handler(void){
  uint pgflt_addr = rcr2();
  pde_t *pgdir = myproc()->pgdir;
  pte_t *pte;
  uint currpage = PGROUNDDOWN(pgflt_addr);
  char *mem;
  //완전히 새로운 페이지를 할당해야 하므로 round up
  pte = walkpgdir(pgdir, (void *)currpage, 0);

  //page fault가 발생한 주소가 page table에 매핑되어 있지 않은 잘못된 범위에 속해 있는 경우 panic 발생
  if(!pte || !(*pte & PTE_P)){
    panic("Page fault");
  }

  //Write 권한이 없는 경우
  if(!(*pte & PTE_W)){
    uint old_pa = PTE_ADDR(*pte);
    uint flags = PTE_FLAGS(*pte);


    if((mem = kalloc()) == 0){
      panic("kalloc error");
    }
    memmove(mem, (char *)P2V(PTE_ADDR(*pte)), PGSIZE);


    //reference 값 하나 낮춤
    decr_refc(PTE_ADDR(old_pa));
    *pte = V2P(mem) | flags | PTE_W;
    lcr3(V2P(pgdir));
    return;
  }
}

int
sys_CoW_handler(void){
  CoW_handler();
  return 0;
}
//PAGEBREAK!
// Blank page.
//PAGEBREAK!
// Blank page.
//PAGEBREAK!
// Blank page.